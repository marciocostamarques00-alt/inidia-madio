import React from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Itinerary from '@/components/Itinerary';
import Differentiators from '@/components/Differentiators';
import Testimonials from '@/components/Testimonials';
import Investment from '@/components/Investment';
import Inclusions from '@/components/Inclusions';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import WhatsAppFloat from '@/components/WhatsAppFloat';

function App() {
  return (
    <>
      <Helmet>
        <title>Madio Viagens | Índia 2025 - Uma Viagem Transformadora</title>
        <meta name="description" content="Participe do grupo exclusivo para a Índia em Outubro de 2025 com Renato Madio. 12 dias de cultura, espiritualidade e experiências inesquecíveis. Vagas limitadas!" />
        <meta property="og:title" content="Madio Viagens | Índia 2025 - Uma Viagem Transformadora" />
        <meta property="og:description" content="Participe do grupo exclusivo para a Índia em Outubro de 2025 com Renato Madio. 12 dias de cultura, espiritualidade e experiências inesquecíveis. Vagas limitadas!" />
        <meta name="keywords" content="viagem Índia 2025, grupo Índia, roteiro Índia com guia em português, Madio Viagens, Renato Madio, viagem de luxo Índia" />
      </Helmet>

      <div className="min-h-screen bg-white text-gray-800">
        <Header />
        <main>
          <Hero />
          <About />
          <Itinerary />
          <Differentiators />
          <Testimonials />
          <Investment />
          <Inclusions />
          <Contact />
        </main>
        <Footer />
        <WhatsAppFloat />
        <Toaster />
      </div>
    </>
  );
}

export default App;