import React from 'react';
import { motion } from 'framer-motion';
import { Users, Globe, Camera, Shield, Heart, Award } from 'lucide-react';

const services = [
  {
    icon: <Users className="w-10 h-10" />,
    title: "Acompanhamento Pessoal",
    description: "Renato Madio acompanha todo o grupo, garantindo uma experiência única."
  },
  {
    icon: <Globe className="w-10 h-10" />,
    title: "Guias Locais em Português",
    description: "Aproveite cada momento sem barreiras de idioma com guias especializados."
  },
  {
    icon: <Camera className="w-10 h-10" />,
    title: "Experiências Únicas",
    description: "Roteiro cultural completo com festivais, cerimônias e passeios."
  },
  {
    icon: <Shield className="w-10 h-10" />,
    title: "Hospedagens Selecionadas",
    description: "Hotéis escolhidos para garantir seu conforto e autenticidade."
  },
  {
    icon: <Heart className="w-10 h-10" />,
    title: "Suporte Personalizado",
    description: "Assistência completa antes, durante e após a sua viagem."
  },
  {
    icon: <Award className="w-10 h-10" />,
    title: "100% de Satisfação",
    description: "Mais de 50 grupos levados à Índia com total aprovação dos viajantes."
  }
];

const Services = () => {
  return (
    <section id="servicos" className="py-24 bg-gray-50 section-clip">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
            Nossos Diferenciais
          </h2>
          <div className="w-24 h-1 primary-gradient mx-auto"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true, amount: 0.5 }}
              className="service-card text-center p-8 rounded-2xl shadow-lg bg-white"
            >
              <div className="text-teal-500 mb-4 inline-block">
                {service.icon}
              </div>
              <h3 className="text-2xl font-bold mb-3 text-gray-800">
                {service.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;