import React from 'react';
import { motion } from 'framer-motion';
import { Check, X, Info } from 'lucide-react';

const inclusionsData = [
  "11 noites de hospedagem em base tripla nos hotéis mencionados, incluindo café da manhã.",
  "Jantar especial de celebração do Diwali com uma família local em Jaipur.",
  "Traje tradicional para a celebração do Diwali (Kurta pijama para homens e sari para mulheres).",
  "Traslados e serviços de recepção nos aeroportos/hotéis realizados por pessoal de língua inglesa.",
  "Assistência e traslados nos aeroportos e hotéis conforme o programa.",
  "01 sessão de Yoga em hotéis de Jaipur.",
  "Traslados, visitas e excursões conforme o programa em veículo com ar-condicionado.",
  "Entradas para os monumentos.",
  "Guia acompanhante de língua portuguesa durante toda a viagem.",
  "Protetores de sapatos e 01 garrafa de água mineral para a visita ao Taj Mahal.",
  "Passagens de trem no trecho Agra-Jhansi em classe A/C Chair Car.",
  "Passeio de Rickshaw em Delhi.",
  "Subida em elefante até o Forte Amber.",
  "Participação na cerimônia Aarti no templo Birla em Jaipur.",
  "Água mineral limitada no veículo durante as visitas/traslados (01 garrafa por pessoa por dia).",
  "Todos os impostos governamentais aplicáveis na data (sujeito a alterações)."
];

const exclusionsData = [
  "Passagem aérea internacional.",
  "Taxas de passaporte e visto para a Índia.",
  "Qualquer refeição ou opção não mencionada no itinerário ou incluída no preço.",
  "Qualquer item de caráter pessoal e gorjetas.",
  "Qualquer tipo de seguro.",
  "Noites adicionais para os participantes, oferecidas com custo adicional.",
  "Não inclui nenhuma bebida, incluindo água mineral, refrigerantes, bebidas alcoólicas, etc., a menos que especificado.",
  "Qualquer tarifa aérea e impostos de aeroporto.",
  "Qualquer item de natureza pessoal, como bebidas, gorjetas (exceto em refeições em grupo e manuseio de bagagem), lavanderia, etc."
];

const commentsData = [
  "Os preços não incluem: aumentos imprevistos no preço do combustível, novos impostos sobre hotéis e serviços de transporte ou qualquer aumento nas taxas de entrada.",
  "O horário de check-in e check-out é às 12:00 do meio-dia, exceto nas propriedades Taj e Oberoi, onde o check-in é às 14:00 e o check-out às 12:00 do meio-dia.",
  "O Taj Mahal está fechado para o público às sextas-feiras.",
  "O passeio de elefante para visitar o Forte Amber em Jaipur está sujeito à disponibilidade. A reserva deve ser feita antecipadamente.",
  "Reservamo-nos o direito de modificar os itinerários e/ou substituir os hotéis por outros de qualidade bastante similar, quando disponível.",
  "Em caso de flutuações cambiais, alterações nos impostos do governo local ou aumento no preço do combustível, reservamo-nos o direito de ajustar o preço do tour."
];

const InfoCard = ({ title, data, icon: Icon, colorClass }) => (
  <motion.div 
    className="bg-white p-8 rounded-2xl shadow-lg h-full"
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
    viewport={{ once: true, amount: 0.3 }}
  >
    <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-6 ${colorClass}`}>
      <Icon className="w-6 h-6 text-white" />
    </div>
    <h3 className="text-2xl font-bold font-serif mb-4">{title}</h3>
    <ul className="space-y-3">
      {data.map((item, index) => (
        <li key={index} className="flex items-start gap-3 text-gray-600">
          <div className="w-5 h-5 flex-shrink-0 mt-1">
            <Icon className={`w-5 h-5 ${colorClass.replace('bg-', 'text-')}`} />
          </div>
          <span>{item}</span>
        </li>
      ))}
    </ul>
  </motion.div>
);

const Inclusions = () => {
  return (
    <section id="detalhes" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold font-serif gradient-text">Detalhes da Viagem</h2>
          <p className="text-lg text-gray-500 mt-2 max-w-2xl mx-auto">
            Para sua tranquilidade, aqui está tudo o que você precisa saber sobre sua jornada.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <InfoCard title="O que está Incluso" data={inclusionsData} icon={Check} colorClass="bg-green-500" />
          <InfoCard title="O que NÃO está Incluso" data={exclusionsData} icon={X} colorClass="bg-red-500" />
        </div>

        <motion.div
          className="bg-muted/60 p-8 rounded-2xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true, amount: 0.3 }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-500">
              <Info className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-2xl font-bold font-serif">Informações Importantes</h3>
          </div>
          <ul className="space-y-3">
            {commentsData.map((item, index) => (
              <li key={index} className="flex items-start gap-3 text-gray-600">
                <Info className="w-5 h-5 text-blue-500 flex-shrink-0 mt-1" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </section>
  );
};

export default Inclusions;