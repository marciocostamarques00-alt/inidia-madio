import React from 'react';
import { motion } from 'framer-motion';
import { UserCheck, Globe, Sparkles, HeartHandshake, BedDouble, Utensils } from 'lucide-react';

const differentiatorsData = [
  { 
    icon: <UserCheck className="w-10 h-10" />, 
    title: "Curadoria de Renato Madio",
    description: "Viaje com a segurança e o conhecimento de um especialista que ama a Índia e cuida de cada detalhe da sua experiência."
  },
  { 
    icon: <Globe className="w-10 h-10" />, 
    title: "Guias em Português",
    description: "Aproveite uma imersão cultural completa, com guias locais fluentes em português para que você não perca nenhuma história."
  },
  { 
    icon: <Sparkles className="w-10 h-10" />, 
    title: "Celebração do Diwali",
    description: "Viva a magia do Festival das Luzes como um local, com trajes tradicionais inclusos para uma experiência autêntica e inesquecível."
  },
  { 
    icon: <HeartHandshake className="w-10 h-10" />, 
    title: "Yoga Exclusiva",
    description: "Conecte-se com a espiritualidade indiana em uma sessão de yoga exclusiva em Jaipur, pensada para renovar corpo e mente."
  },
  { 
    icon: <BedDouble className="w-10 h-10" />, 
    title: "Hospedagens de Luxo",
    description: "Descanse em hotéis 5 estrelas cuidadosamente selecionados, que combinam conforto, sofisticação e a hospitalidade indiana."
  },
  { 
    icon: <Utensils className="w-10 h-10" />, 
    title: "Imersão Cultural",
    description: "Explore a Índia através de todos os sentidos, com experiências gastronômicas, artísticas e espirituais que vão além do turismo tradicional."
  },
];

const Differentiators = () => {
  const cardVariants = {
    offscreen: {
      y: 50,
      opacity: 0
    },
    onscreen: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        bounce: 0.4,
        duration: 0.8
      }
    }
  };

  return (
    <section id="diferenciais" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 font-serif gradient-text">
            Por que viajar com a Madio?
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Não vendemos apenas uma viagem, oferecemos uma transformação. Cada detalhe é pensado para que sua única preocupação seja viver a Índia em sua plenitude.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {differentiatorsData.map((item, index) => (
            <motion.div
              key={index}
              initial="offscreen"
              whileInView="onscreen"
              viewport={{ once: true, amount: 0.5 }}
              variants={cardVariants}
              transition={{ delay: index * 0.1 }}
              className="bg-muted/40 rounded-2xl p-8 text-center shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 group flex flex-col items-center"
            >
              <div className="mb-5 p-4 rounded-full primary-gradient text-white shadow-lg group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{item.title}</h3>
              <p className="text-gray-600 leading-relaxed">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Differentiators;