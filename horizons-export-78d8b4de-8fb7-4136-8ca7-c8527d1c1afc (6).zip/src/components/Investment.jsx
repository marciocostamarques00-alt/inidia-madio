import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle, CalendarDays, Star, Map, UserCheck, Tag, Sparkles } from 'lucide-react';
import { openWhatsApp } from '@/lib/utils';
const Investment = () => {
  const inclusions = [{
    icon: <Star className="w-5 h-5 text-accent" />,
    text: "Hospedagem em hotéis 5 estrelas"
  }, {
    icon: <Map className="w-5 h-5 text-accent" />,
    text: "Roteiro terrestre completo"
  }, {
    icon: <UserCheck className="w-5 h-5 text-accent" />,
    text: "Guia acompanhante em português"
  }, {
    icon: <Sparkles className="w-5 h-5 text-accent" />,
    text: "Acompanhamento de Renato Madio"
  }];
  return <section id="investimento" className="py-24 bg-muted/50">
      <div className="container mx-auto px-4">
        <motion.div initial={{
        opacity: 0,
        y: 50
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} viewport={{
        once: true,
        amount: 0.3
      }}>
          <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden grid lg:grid-cols-2">
            <div className="p-8 md:p-12 order-2 lg:order-1 flex flex-col">
              <h2 className="text-4xl font-bold font-serif mb-2 leading-tight">Diwali: <br/>Festival das Luzes</h2>
              <p className="text-lg text-gray-500 mb-6">"Viagem em grupo ao que há de mais belo na ÍNDIA"</p>

              <div className="bg-muted/60 p-4 rounded-xl mb-6 flex items-center gap-4">
                 <CalendarDays className="w-8 h-8 text-primary" />
                 <div>
                    <p className="font-bold text-gray-800">16 a 27 de Outubro de 2025</p>
                    <p className="text-sm text-gray-600">12 dias de imersão e descobertas</p>
                 </div>
              </div>

              <div className="space-y-3 mb-8">
                {inclusions.map((item, index) => <div key={index} className="flex items-center gap-3">
                    {item.icon}
                    <span className="text-gray-700">{item.text}</span>
                  </div>)}
              </div>
              
              <div className="mt-auto">
                 <Button onClick={openWhatsApp} size="lg" className="w-full secondary-gradient text-white font-bold text-lg py-7 btn-hover-gold">
                    Faça sua reserva
                  </Button>
              </div>

            </div>

            <div className="p-8 md:p-12 order-1 lg:order-2 bg-gradient-to-br from-primary to-accent/90 flex flex-col justify-center items-center text-center text-white relative">
              <div className="absolute top-4 right-4 bg-red-600 text-white font-bold py-2 px-4 rounded-full text-sm transform rotate-12 shadow-lg flex items-center gap-2">
                <Tag className="w-4 h-4" />
                <span>DESCONTO DE 619 USD</span>
              </div>
              
              <h3 className="text-xl font-semibold opacity-90">Investimento por pessoa</h3>
              <p className="text-xl font-light opacity-80 mt-4">De <span className="line-through">USD 3.198</span> por</p>
              <p className="text-6xl font-bold my-1 text-shadow">
                USD 2.579
              </p>
              <p className="opacity-90 mb-4">em apartamento duplo</p>
              
              <div className="w-full h-px bg-white/30 my-6"></div>

              <p className="font-semibold text-lg">Oferta Exclusiva!</p>
              <p className="text-sm opacity-90 max-w-xs mx-auto">
                Garanta o desconto especial para inscrições feitas até <strong>Setembro de 2025.</strong>
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>;
};
export default Investment;