import React from 'react';
import { Facebook, Instagram, Globe } from 'lucide-react';

const Footer = () => {
  const socialLinks = {
    facebook: 'https://www.facebook.com/madioviagens',
    instagram: 'https://www.instagram.com/madioviagens/',
    website: 'https://www.madioviagens.com.br/'
  };

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4 text-center">
        <span className="text-3xl font-bold font-serif text-white">Madio Viagens</span>
        <p className="text-gray-400 mt-4 max-w-md mx-auto text-sm">
          Criando jornadas transformadoras para a Índia desde 2004.
        </p>
        <div className="flex justify-center gap-6 my-8">
          <a href={socialLinks.facebook} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors"><Facebook /></a>
          <a href={socialLinks.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors"><Instagram /></a>
          <a href={socialLinks.website} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors"><Globe /></a>
        </div>
        <div className="text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Madio Viagens. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;