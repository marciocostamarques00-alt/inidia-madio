import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonialsData = [
  { name: "Juliana S.", text: "A viagem com a Madio foi transformadora, voltei com a alma renovada." },
  { name: "Ricardo A.", text: "Tudo impecável, do roteiro à atenção da equipe. Experiência única!" },
  { name: "Fernanda M.", text: "O cuidado nos detalhes faz toda a diferença. Me senti segura em todo o momento." },
  { name: "Paulo V.", text: "Participar da cerimônia no Ganges foi emocionante, nunca esquecerei." },
  { name: "Camila L.", text: "O Diwali foi mágico! Parecia que eu fazia parte da cultura indiana." },
  { name: "Marcelo D.", text: "Renato é incrível, transmite confiança e paixão pelo que faz." },
  { name: "Simone R.", text: "Vale cada centavo, voltei com lembranças e amigos para a vida toda." },
  { name: "Adriana F.", text: "Já viajei muito, mas essa foi a mais completa e organizada da minha vida." },
  { name: "André C.", text: "Tudo fluía com naturalidade, parecia que a equipe previa nossas necessidades." },
  { name: "Beatriz F.", text: "Não é só turismo, é uma imersão cultural e espiritual verdadeira." },
];

const Testimonials = () => {
  const carouselRef = useRef(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    setWidth(carouselRef.current.scrollWidth - carouselRef.current.offsetWidth);
  }, []);

  return (
    <section id="depoimentos" className="py-24 bg-muted/50 overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 font-serif gradient-text">
            Viajantes que se Transformaram
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A maior prova da nossa excelência é a satisfação de quem já viajou conosco.
          </p>
        </motion.div>

        <motion.div ref={carouselRef} className="cursor-grab">
          <motion.div 
            drag="x" 
            dragConstraints={{ right: 0, left: -width }}
            className="flex gap-8"
          >
            {testimonialsData.map((testimonial, index) => (
              <motion.div 
                key={index}
                className="min-w-[300px] md:min-w-[350px] bg-white p-8 rounded-2xl shadow-xl flex flex-col"
              >
                <Quote className="w-10 h-10 text-primary/30 mb-4" />
                <p className="text-gray-600 italic mb-6 flex-grow">
                  "{testimonial.text}"
                </p>
                <div className="mt-auto border-t pt-4">
                  <div className="flex mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <h4 className="font-bold text-gray-800 text-lg">{testimonial.name}</h4>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
        <p className="text-center text-gray-500 mt-8 text-sm">Arraste para o lado para ver mais depoimentos</p>
      </div>
    </section>
  );
};

export default Testimonials;