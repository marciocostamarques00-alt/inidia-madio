import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { openWhatsApp } from '@/lib/utils';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Sobre', href: '#sobre' },
    { name: 'Roteiro', href: '#roteiro' },
    { name: 'Diferenciais', href: '#diferenciais' },
    { name: 'Depoimentos', href: '#depoimentos' },
    { name: 'Investimento', href: '#investimento' },
    { name: 'Contato', href: '#contato' },
  ];

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-lg shadow-md' : 'bg-transparent'}`}>
      <div className="container mx-auto px-4 flex justify-between items-center h-20">
        <a href="#hero" className="flex items-center gap-2">
          <span className={`text-2xl font-bold font-serif transition-colors ${isScrolled ? 'gradient-text' : 'text-white'}`}>Madio Viagens</span>
        </a>
        <nav className="hidden lg:flex items-center gap-6">
          {navLinks.map(link => (
            <a key={link.name} href={link.href} className={`font-medium transition-colors ${isScrolled ? 'text-gray-700 hover:text-primary' : 'text-white hover:text-gray-200'}`}>{link.name}</a>
          ))}
        </nav>
        <div className="hidden lg:block">
          <Button onClick={openWhatsApp} className="secondary-gradient text-white font-bold btn-hover-gold">
            Fale com um especialista
          </Button>
        </div>
        <div className="lg:hidden">
          <Button onClick={() => setIsOpen(!isOpen)} variant="ghost" size="icon" className={isScrolled ? 'text-gray-800' : 'text-white'}>
            {isOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:hidden bg-white shadow-lg"
        >
          <nav className="flex flex-col items-center p-4 gap-4">
            {navLinks.map(link => (
              <a key={link.name} href={link.href} onClick={() => setIsOpen(false)} className="font-medium text-gray-700 hover:text-primary w-full text-center py-2">{link.name}</a>
            ))}
            <Button onClick={openWhatsApp} className="w-full secondary-gradient text-white font-bold btn-hover-gold">
              Fale com um especialista
            </Button>
          </nav>
        </motion.div>
      )}
    </header>
  );
};

export default Header;