import React, { useState } from 'react';
import { motion } from 'framer-motion';
import CountUp from 'react-countup';
import { PlayCircle } from 'lucide-react';

const StatCounter = ({ end, label }) => {
  return (
    <div className="text-center">
      <div className="text-4xl md:text-5xl font-bold gradient-text">
        <CountUp end={end} duration={3} enableScrollSpy scrollSpyOnce />{label === 'Satisfação' ? '%' : '+'}
      </div>
      <p className="text-sm md:text-base text-gray-600 mt-1">{label}</p>
    </div>
  );
};

const About = () => {
  const [playVideo, setPlayVideo] = useState(false);
  const videoThumbnail = "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/998db660eea21a81713871f390bc5ad8.png";
  
  return (
    <section id="sobre" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true, amount: 0.5 }}
            className="relative rounded-2xl overflow-hidden shadow-2xl aspect-video"
          >
            {playVideo ? (
              <div style={{padding:"56.25% 0 0 0", position:"relative"}}>
                <iframe 
                  src="https://player.vimeo.com/video/1112905461?autoplay=1&badge=0&autopause=0&player_id=0&app_id=58479" 
                  frameBorder="0" 
                  allow="autoplay; fullscreen; picture-in-picture; clipboard-write" 
                  style={{position:"absolute", top:0, left:0, width:"100%", height:"100%"}} 
                  title="MADIO VIAGEM - Convite para Diwalli na Índia">
                </iframe>
              </div>
            ) : (
              <div onClick={() => setPlayVideo(true)} className="cursor-pointer relative w-full h-full">
                <img src={videoThumbnail} alt="Capa do vídeo - Renato te convida para Diwali na Índia" className="w-full h-full object-cover"/>
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                   <PlayCircle className="text-white/80 w-20 h-20 hover:text-white hover:scale-110 transition-transform duration-300" />
                </div>
              </div>
            )}
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, amount: 0.5 }}
            className="space-y-6"
          >
            <h2 className="text-4xl font-bold font-serif gradient-text">Olá, Bem-vindo à Madio Viagens</h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Com mais de 20 anos de experiência, Renato Madio e a Madio Viagens são especialistas em criar jornadas únicas, com foco em sofisticação, segurança e imersão cultural.
            </p>
            <p className="text-base text-gray-600 leading-relaxed">
              Renato, também criador do perfil “Viagem com Renato”, levará pessoalmente um grupo para uma jornada exclusiva pela Índia, unindo cultura, espiritualidade e celebrações autênticas como o Diwali.
            </p>
             <p className="text-lg font-semibold text-gray-800 border-l-4 border-primary pl-4">Uma oportunidade de viajar com curadoria de quem conhece profundamente o destino e transformar sua forma de viver o mundo.</p>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
               <StatCounter end={57} label="Grupos" />
               <StatCounter end={12} label="Países" />
               <StatCounter end={100} label="Satisfação" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
export default About;