import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { openWhatsApp } from '@/lib/utils';
const images = [{
  src: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/eebed483292bbad1cd647fb7218bd4c8.jpg",
  alt: "Duas mulheres indianas sorrindo e celebrando o festival de Diwali com luzes ao fundo"
}, {
  src: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/8ed9cf36b71dc3b46c52acfd6797eddf.jpg",
  alt: "Mulher indiana em primeiro plano com as mãos formando um quadro e o Taj Mahal ao fundo"
}, {
  src: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/133c7a0f762f070db5937bd662869dc4.png",
  alt: "Turistas brasileiros felizes passeando de elefante no Forte Amber em Jaipur ao pôr do sol"
}, {
  src: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da",
  alt: "O majestoso Taj Mahal refletido na água ao amanhecer"
}];
const Hero = () => {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setIndex(prev => (prev + 1) % images.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  const currentImage = images[index];
  return <section id="hero" className="relative h-screen flex items-center justify-center text-white overflow-hidden bg-black">
      <AnimatePresence initial={false} custom={index}>
        <motion.div key={index} initial={{
        opacity: 0,
        scale: 1.1
      }} animate={{
        opacity: 1,
        scale: 1
      }} exit={{
        opacity: 0,
        scale: 1.1
      }} transition={{
        duration: 1.5,
        ease: "easeInOut"
      }} className="absolute inset-0 z-0">
          {currentImage && <>
              <img src={currentImage.src} alt={currentImage.alt} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/50"></div>
            </>}
        </motion.div>
      </AnimatePresence>
      
      <div className="relative z-10 container mx-auto px-4 text-center">
        <motion.div initial={{
        opacity: 0,
        y: 50
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.5
      }} className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-4 font-serif leading-tight">Viajar para a Índia é Especial. Viajar com a Madio é Inesquecível.</h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8">Do brilho do Diwali ao nascer do sol no Ganges – 12 dias com Renato Madio que ficarão para sempre na memória.</p>
          <Button onClick={openWhatsApp} size="lg" className="px-10 py-6 text-lg font-semibold secondary-gradient text-white hover:scale-105 transition-transform shadow-2xl btn-hover-gold">
            Reserve sua vaga agora
          </Button>
        </motion.div>
      </div>
    </section>;
};
export default Hero;