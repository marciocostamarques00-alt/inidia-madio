import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const itineraryData = [
  {
    day: "Dias 1-3",
    city: "Delhi",
    title: "A Capital Vibrante",
    description: "Explore a intensidade de Old e New Delhi: mesquitas monumentais como Jama Masjid, o memorial de Gandhi, mercados caóticos em rickshaw e templos modernos como o Sikh Gurudwara. Uma cidade que revela o passado e o futuro da Índia lado a lado.",
    imageSrc: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/delhi-a-jama-masjid-v3IYK.png",
    imageAlt: "Templo do Lótus em Delhi ao pôr do sol"
  },
  {
    day: "Dias 4-5",
    city: "Jaipur",
    title: "A Cidade Rosa",
    description: "Entre palácios e fortalezas, Jaipur encanta com o majestoso Forte Amber, o Palácio dos Ventos e mercados vibrantes. Viva tradições únicas: yoga ao amanhecer, jantar com família local e a celebração do Diwali, o Festival das Luzes.",
    imageSrc: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/jaipur-a-forte-amber-6OvXg.png",
    imageAlt: "Palácio Hawa Mahal em Jaipur com sua fachada rosa icônica"
  },
  {
    day: "Dias 6-7",
    city: "Agra",
    title: "O Ícone do Amor",
    description: "Conheça o eterno símbolo do amor: o Taj Mahal, um dos monumentos mais célebres do mundo. Explore também o Forte Vermelho e reviva a grandiosidade mogol em meio a jardins, palácios e histórias de paixão e poder.",
    imageSrc: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/agra-a-taj-mahal-QssxZ.png",
    imageAlt: "O majestoso Taj Mahal refletido na água ao amanhecer"
  },
  {
    day: "Dias 8-9",
    city: "Varanasi",
    title: "A Cidade Espiritual",
    description: "Nas margens sagradas do rio Ganges, testemunhe rituais ancestrais de purificação, o nascer do sol em um passeio de barco e cerimônias de fogo nos Ghats. Uma experiência espiritual que conecta corpo, mente e alma.",
    imageSrc: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/varanasi-a-passeio-no-ganges-anEs3.png",
    imageAlt: "Barcos no Rio Ganges em Varanasi durante uma cerimônia espiritual"
  },
  {
    day: "Dias 10-12",
    city: "Khajuraho & Diwali",
    title: "Templos e Luzes",
    description: "Descubra os templos de Khajuraho, famosos por esculturas únicas que retratam espiritualidade e arte da Índia medieval. Encerramos com a celebração do Diwali, o Festival das Luzes, vivendo a magia e a energia vibrante da Índia em festa.",
    imageSrc: "https://horizons-cdn.hostinger.com/78d8b4de-8fb7-4136-8ca7-c8527d1c1afc/20250825_1152_celebraassapso-diwali-festiva_simple_compose_01k3gvca64epg8bjhxh396eyba-OJh9l.png",
    imageAlt: "Família indiana celebrando o festival Diwali com luzes e velas"
  }
];

const Itinerary = () => {
  const [selectedCity, setSelectedCity] = useState(itineraryData[0]);

  return (
    <section id="roteiro" className="py-24 bg-muted/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 font-serif gradient-text">
            Um Roteiro Inesquecível
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Explore cada etapa desta jornada transformadora. Selecione uma cidade para descobrir os detalhes da sua próxima aventura.
          </p>
        </motion.div>

        <div className="flex flex-col lg:flex-row gap-8 max-w-6xl mx-auto items-center">
          <div className="w-full lg:w-1/3 flex flex-col gap-4">
            {itineraryData.map((item) => (
              <motion.div
                key={item.city}
                onClick={() => setSelectedCity(item)}
                className={`p-4 rounded-lg cursor-pointer border-2 transition-all duration-300 ${
                  selectedCity.city === item.city
                    ? 'bg-white shadow-lg border-primary'
                    : 'bg-white/50 border-transparent hover:bg-white hover:shadow-md'
                }`}
                whileHover={{ scale: 1.03 }}
              >
                <p className="font-bold text-gray-500 text-sm">{item.day}</p>
                <h3 className="text-xl font-bold font-serif gradient-text">{item.city}</h3>
                <p className="text-gray-600 text-sm">{item.title}</p>
              </motion.div>
            ))}
          </div>

          <div className="w-full lg:w-2/3">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedCity.city}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="relative aspect-[4/3] w-full rounded-2xl shadow-2xl overflow-hidden"
              >
                <img
                  src={selectedCity.imageSrc}
                  alt={selectedCity.imageAlt}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex flex-col justify-end p-8 text-white">
                  <motion.h3
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className="text-3xl font-bold font-serif"
                  >
                    {selectedCity.city}
                  </motion.h3>
                  <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.3 }}
                    className="mt-2 text-base"
                  >
                    {selectedCity.description}
                  </motion.p>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Itinerary;