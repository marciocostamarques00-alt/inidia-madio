import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { MessageCircle } from 'lucide-react';
import { openWhatsApp } from '@/lib/utils';

const WhatsAppFloat = () => {
  return (
    <motion.div
      className="whatsapp-float"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
    >
      <Button
        onClick={openWhatsApp}
        className="w-16 h-16 rounded-full secondary-gradient text-white shadow-2xl pulse-glow"
        aria-label="Fale conosco no WhatsApp"
      >
        <MessageCircle className="w-8 h-8" />
      </Button>
    </motion.div>
  );
};

export default WhatsAppFloat;