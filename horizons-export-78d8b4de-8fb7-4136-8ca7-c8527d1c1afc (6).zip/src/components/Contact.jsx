import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Send } from 'lucide-react';

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: ''
  });

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const leads = JSON.parse(localStorage.getItem('madio-leads') || '[]');
    const newLead = { ...formData, data: new Date().toISOString(), id: Date.now() };
    leads.push(newLead);
    localStorage.setItem('madio-leads', JSON.stringify(leads));
    
    toast({
      title: "Obrigado pelo seu interesse! 🙏",
      description: "Em breve nossa equipe entrará em contato com você!",
    });
    
    setFormData({ nome: '', email: '', telefone: '' });
  };

  return (
    <section id="contato" className="py-24 bg-muted/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.5 }}
          className="text-center mb-12 max-w-3xl mx-auto"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 font-serif gradient-text">
            Fale com nossa equipe
          </h2>
          <p className="text-lg text-gray-600">
            Receba todos os detalhes da viagem e tire suas dúvidas. Estamos prontos para te atender!
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.5 }}
          className="max-w-lg mx-auto bg-white p-8 rounded-2xl shadow-xl"
        >
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="sr-only">Nome</label>
              <input
                type="text"
                name="nome"
                value={formData.nome}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 rounded-lg bg-gray-100 border-2 border-transparent focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Nome"
              />
            </div>
            <div>
              <label className="sr-only">E-mail</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 rounded-lg bg-gray-100 border-2 border-transparent focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="E-mail"
              />
            </div>
            <div>
              <label className="sr-only">Telefone</label>
              <input
                type="tel"
                name="telefone"
                value={formData.telefone}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 rounded-lg bg-gray-100 border-2 border-transparent focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Telefone"
              />
            </div>
            <Button
              type="submit"
              className="w-full py-3 text-lg font-semibold secondary-gradient text-white hover:scale-105 transition-transform shadow-md btn-hover-gold"
            >
              <Send className="w-5 h-5 mr-2" />
              Enviar
            </Button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;